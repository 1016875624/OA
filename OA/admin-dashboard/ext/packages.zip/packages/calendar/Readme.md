# calendar 

The Ext JS calendar is a powerful new component that allows users to incorporate their date and event data to create stunning custom calendars.

