/**
 *
 */
Ext.define('Ext.chart.navigator.ContainerBase', {
    extend: 'Ext.panel.Panel'
});