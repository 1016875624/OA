At the time of this writing, the 'charts' package is tested with the 'classic' theme.

See ext/classic/classic/test/bootstrap.css

Make sure you've build the package for all themes ('sencha package build') or for the 'classic'
theme specifically before running the specs locally.

