Ext.define('Ext.chart.theme.Green', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.green',
        'chart.theme.Green'
    ],
    config: {
        baseColor: '#b1da5a'
    }
});