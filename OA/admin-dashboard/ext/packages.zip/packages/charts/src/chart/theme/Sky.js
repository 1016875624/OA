Ext.define('Ext.chart.theme.Sky', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.sky',
        'chart.theme.Sky'
    ],
    config: {
        baseColor: '#4ce0e7'
    }
});