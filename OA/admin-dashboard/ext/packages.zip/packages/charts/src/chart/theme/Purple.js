Ext.define('Ext.chart.theme.Purple', {
    extend: 'Ext.chart.theme.Base',
    singleton: true,
    alias: [
        'chart.theme.purple',
        'chart.theme.Purple'
    ],
    config: {
        baseColor: '#da5abd'
    }
});